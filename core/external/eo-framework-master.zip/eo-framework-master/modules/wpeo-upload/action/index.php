<?php
// Silence is golden!