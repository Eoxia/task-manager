<?php
/**
 * Le titre par défault dans la modal.
 *
 * @author Eoxia <dev@eoxia.com>
 * @since 1.0.0
 * @version 1.0.0
 * @copyright 2015-2018 Eoxia
 * @package EO_Framework\Core\View
 */

namespace digi;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

Défaut modal titre
