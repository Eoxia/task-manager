# EoxiaJS

Framework JS by Eoxia. Current version 1.0.0-easy

# To do
### 1.1.0

* **action.backend.js**: Replace the three actions to one.
* Add comments in code
* Update wiki

[Wiki](https://github.com/Eoxia/EoxiaJS/wiki)
